import { SecretSantaPage } from './app.po';

describe('secret-santa App', () => {
  let page: SecretSantaPage;

  beforeEach(() => {
    page = new SecretSantaPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
