import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { RegisterFormService } from './register-form/register-form.service';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AdminComponent } from './admin/admin.component';
import { DateValidator } from './register-form/date.Validator';
import { HomeComponent } from './home/home.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { ChildComponent } from './child/child.component';
import { SantaComponent } from './santa/santa.component';
import { SantaServiceService } from './santa/santa-service.service';
import { ParticlesComponent } from './particles/particles.component';
import { AdminService } from './admin/admin.service';
import { OrganizerComponent } from './organizer/organizer.component';
import { OrganizerService } from './organizer/organizer.service';
import { ChildService } from './child/child.service';
import { LoginFormService } from './login-form/login-form.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    RegisterFormComponent,
    UserLoginComponent,
    ChildComponent,
    SantaComponent,
    AdminComponent,
    HomeComponent,
    ParticlesComponent,
    OrganizerComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpModule
  ],
  providers: [RegisterFormService, SantaServiceService, AdminService, OrganizerService, LoginFormService,ChildService],
  bootstrap: [AppComponent]
})
export class AppModule { }
