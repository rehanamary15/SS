import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SantaServiceService } from '../santa/santa-service.service';
import { RegisterFormService } from '../register-form/register-form.service';
import { OrganizerService } from './organizer.service';
import { Http } from '@angular/http';

@Component({
  selector: 'app-organizer',
  templateUrl: './organizer.component.html',
  styleUrls: ['./organizer.component.css']
})
export class OrganizerComponent implements OnInit {

  organizer:string
  id:string
  santaForm:FormGroup
  successMessage:string
  errorMessage:string
  savedTasks:string[]
  showCalled:boolean=false
  giftCalled:boolean
  taskIds:number[]
  task: object[]
  giftRow:object[]
  errorMessage1:string

  
  name:string
  phoneNumber:string
  groupId:string
  myObj:object
  

  constructor(private fb:FormBuilder, private activatedRoute:ActivatedRoute, private obj:OrganizerService)
   { 
    this.savedTasks=new Array()
    this.taskIds=new Array()
    this.showCalled=false
    this.successMessage=null
    this.errorMessage=null
    this.id=null
    this.organizer=""
    this.giftCalled=false
  
    this.name=null
    this.phoneNumber=null
    this.groupId=null

  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => { this.id = params['id'], this.organizer=params['message']});
    
    this.santaForm=this.fb.group({
      taskDescription:["",Validators.required],
      empId:[this.id,Validators.required]
    })
  }

  allTasks(id)
  {
    this.errorMessage1=null;
    this.obj.allTasks({empId:this.id})
    .then(a=>{
    this.task=a
    console.log(a)
    this.showCalled=true})
    .catch(e=>this.errorMessage1=e[0].message)

  
  }

  authenticateTask(data)
  {
    let taskIdJson={taskId:data}
    this.obj.authenticateTask(taskIdJson)
    .then(a=>{this.successMessage=a.message
    this.allTasks({empId:this.id})})
    .catch(e=>this.errorMessage=e.message)
  }
  
  deleteTask(data)
  {
    let a:any={taskId:data}
    this.obj.deleteTask(a)
    .then(a=>{
      this.allTasks({empId:this.id})})
  }

  getGiftHistory()
  {
    this.obj.getGiftHistory({empId:this.id})
    .then(a=>{
      this.giftRow=a
      this.giftCalled=true  
    })
  }

  getDetails(data){
    this.myObj=null
    this.name=null
    this.phoneNumber=null
    this.groupId=null
    this.obj.getDetails({empId:data})
    .then(a=>{
      this.name=a.name
      this.phoneNumber=a.phoneNumber
      this.groupId=a.groupId
      alert("Name: "+a.name+"\n"+"Phone Number: "+a.phoneNumber+"\n"+"Group Id: "+a.groupId)
    })
   
   

  
  }

}
