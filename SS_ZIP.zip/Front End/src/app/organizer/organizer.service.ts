import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable()
export class OrganizerService {

  constructor(private http:Http) { }

  allTasks(data):Promise<any>
  {
    return this.http.post(environment.allTasks,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }

  authenticateTask(data):Promise<any>
  {
    return this.http.post(environment.authenticateTask,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  deleteTask(data):Promise<any>
  {
    return this.http.post(environment.deleteTask,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }

  getGiftHistory(data):Promise<any>
  {
    return this.http.post(environment.getGiftHistory,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  getDetails(data):Promise<any>
  {
    return this.http.post(environment.getDetails,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }

  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }

}
