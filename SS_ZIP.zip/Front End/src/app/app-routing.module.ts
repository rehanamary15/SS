import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterFormComponent } from './register-form/register-form.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { ChildComponent } from './child/child.component';
import { SantaComponent } from './santa/santa.component';
import { OrganizerComponent } from './organizer/organizer.component';


const routes: Routes = [
  { path:'admin', component:AdminComponent},
  
  
  { path:'user-login/:id/:message', component:UserLoginComponent, children:[
    { path:'child/:id', component:ChildComponent},
    { path:'santa/:id', component:SantaComponent},
    { path:'organizer/:id', component:OrganizerComponent}
  
    ]},

  { path:'home', component:HomeComponent, children:[
    { path:'login-form', component:LoginFormComponent},
    { path:'register-form', component:RegisterFormComponent }]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
