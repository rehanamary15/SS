import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../environments/environment';

@Injectable()
export class AdminService {

  constructor(private http:Http) {

   }
   assign() :Promise<any>{
    return this.http.get(environment.assign)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)

}

assignFlag() :Promise<any>{
  return this.http.get(environment.assignFlag)
  .toPromise()
  .then(a=>a.json() as any)
  .catch(this.errorHandler)

}

showAll() :Promise<any>{
  return this.http.get(environment.showAll)
  .toPromise()
  .then(a=>a.json() as any)
  .catch(this.errorHandler)

}
assignOrganizer(data) :Promise<any>{
  return this.http.post(environment.assignOrganizer,data)
  .toPromise()
  .then(a=>a.json() as any)
  .catch(this.errorHandler)

}


getChildSantaDetails(data):Promise<any>
{
  return this.http.post(environment.getChildSantaDetails,data)
  .toPromise()
  .then(a=>a.json() as any)
  .catch(this.errorHandler)
}

getFlagDetails():Promise<any>
{
  return this.http.get(environment.getFlagDetails)
  .toPromise()
  .then(a=>a.json() as any)
  .catch(this.errorHandler)
}

postFlagDetails(data):Promise<any>{
  return this.http.post(environment.postFlagDetails,data)
  .toPromise()
  .then(a=>a.json() as any)
  .catch(this.errorHandler)
}

getOrganizerTasks():Promise<any>{
  return this.http.get(environment.getOrganizerTasks)
  .toPromise()
  .then(a=>a.json() as any)
  .catch(this.errorHandler)
}


authenticateTask(data):Promise<any>
  {
    return this.http.post(environment.authenticateTask,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  deleteTask(data):Promise<any>
  {
    return this.http.post(environment.deleteTask,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  getDetails(data):Promise<any>
  {
    return this.http.post(environment.getDetails,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }

  deleteAll():Promise<any>
  {
    return this.http.get(environment.deleteAll)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }


private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.json() || error);
  }

}
