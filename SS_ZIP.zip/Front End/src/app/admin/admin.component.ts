import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { AdminService } from './admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  santaChild: object[]
  errorMessage: string
  errorMessageAssign:string
  successMessage: string
  successMessage2:boolean
  showGroupsFlag: boolean
  assignOrgFlag: boolean
  showFlag: boolean
  organizerTaskCalled:boolean
  employees: object[]
  assignSuccess: string
  assignError: string
  taskRow:object[]
  groupName: string
  groupA: object[]
  groupB: object[]
  groupC: object[]
  flagA: boolean
  flagB: boolean
  flagC: boolean
  assignFlag:boolean
  childSanta:object[]
  statusMessage:string
  successMessageAssign:string
  errorMessageTask:string
  errorMessageTaskList:string
  deleteMessage:string

  errorMessageDelete:boolean
  successMessageDelete:boolean


  
  name:string
  phoneNumber:string
  groupId:string
  myObj:object


  constructor(private http: Http, private service: AdminService) {
    this.errorMessage = null
    this.successMessage = null
    this.groupName = null
    this.showGroupsFlag = false
    this.assignOrgFlag = false
    this.showFlag = false
    this.organizerTaskCalled=false
    this.successMessage2=false
    this.childSanta=null
    this.statusMessage=null
    this.errorMessageAssign=null
    this.assignFlag=null
    this.errorMessageTaskList=null
    this.deleteMessage=null
    
    
    this.name=null
    this.phoneNumber=null
    this.groupId=null


  }

  ngOnInit() {
    this.service.getFlagDetails()
      .then(
        a => {
          if (a["A"] == "true")
            this.flagA = true
          else
            this.flagA = false

          if (a["B"] == "true")
            this.flagB = true
          else
            this.flagB = false
          if (a["C"] == "true")
            this.flagC = true
          else
            this.flagC = false
          
          
          if(a["assignFlag"]=="true")
            this.assignFlag=true
          else
            this.assignFlag=false
            


        })
  }

  assign() {
    this.errorMessageAssign=null
    this.successMessageAssign=null

    
    
    this.service.assign()
      .then(a => {this.successMessageAssign = a.message
        this.service.assignFlag().then(a=>{
          if(a["assignFlag"]=="true")
            this.assignFlag=true
          else
            this.assignFlag=false})})
      .catch(e => this.errorMessageAssign = e.message)

  }

  showAll() {
    this.errorMessageTask=null

    this.service.showAll()
      .then(a => {
        this.employees = a
        this.assignOrgFlag = true
        this.groupA = a["A"]
        this.groupB = a["B"]
        this.groupC = a["C"]
      })
      .catch(e => this.errorMessageTask = e["error"][0].message)

  }
  assignOrganizer(employee) {
    
    this.showFlag = false
    let a: any = {
      "empId": employee
    }
    this.service.assignOrganizer(a)
      .then(a => this.assignSuccess = a.message)
      .catch(e => this.assignError = e.message)
  }
  clickA(data) {
    this.service.postFlagDetails({groupId:data}).then(
      a => {
        if (a["A"] == "true")
          this.flagA = true
        else
          this.flagA = false

        if (a["B"] == "true")
          this.flagB = true
        else
          this.flagB = false
        if (a["C"] == "true")
          this.flagC = true
        else
          this.flagC = false


      })
  }
  clickB(data) {
    this.service.postFlagDetails({groupId:data}).then(
      a => {
        if (a["A"] == "true")
          this.flagA = true
        else
          this.flagA = false

        if (a["B"] == "true")
          this.flagB = true
        else
          this.flagB = false
        if (a["C"] == "true")
          this.flagC = true
        else
          this.flagC = false


      })
  }
  clickC(data) {
    this.service.postFlagDetails({groupId:data}).then(
      a => {
        if (a["A"] == "true")
          this.flagA = true
        else
          this.flagA = false

        if (a["B"] == "true")
          this.flagB = true
        else
          this.flagB = false
        if (a["C"] == "true")
          this.flagC = true
        else
          this.flagC = false


      })
  }


  getChildSantaDetails(data) {
    this.statusMessage=null
    this.groupName = data
    this.service.getChildSantaDetails(data)
      .then(a => {

       
        this.santaChild = a
        this.showGroupsFlag = true
      })
      .catch(e =>{this.childSanta = e
      this.statusMessage=e[0].giftStatus})    
  }

  getOrganizerTasks(){
    this.errorMessageTaskList=null
    this.organizerTaskCalled=false

    this.service.getOrganizerTasks()
    .then(a=>{this.taskRow=a
    this.organizerTaskCalled=true})
    .catch(e=>{this.errorMessageTaskList=e[0].message
    })
   
    
  }

  authenticateTask(data)
  {
    let taskIdJson={taskId:data}
    this.service.authenticateTask(taskIdJson)
    .then(a=>{this.successMessage2=true
    this.getOrganizerTasks()})
    .catch(e=>this.errorMessage=e.message)
  }
  
  deleteTask(data)
  {
    let a:any={taskId:data}
    this.service.deleteTask(a)
    .then(a=>{
      this.getOrganizerTasks()})
  }

  
  getDetails(data){
    this.myObj=null
    this.name=null
    this.phoneNumber=null
    this.groupId=null
    this.service.getDetails({empId:data})
    .then(a=>{
      this.name=a.name
      this.phoneNumber=a.phoneNumber
      this.groupId=a.groupId
      alert("Name: "+a.name+"\n"+"Phone Number: "+a.phoneNumber+"\n"+"Group Id: "+a.groupId)
    })
}
deleteAll(){
  this.successMessageDelete=false
  this.deleteMessage=null
  
  alert("Are you sure you want to delete?")
  this.service.deleteAll()
  .then(e=>this.deleteMessage=e)


  this.successMessageDelete=true

}

}