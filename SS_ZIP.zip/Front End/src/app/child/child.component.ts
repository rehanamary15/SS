import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterFormService } from '../register-form/register-form.service';
import { ActivatedRoute } from '@angular/router';
import { ChildService } from './child.service';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  taskForm:FormGroup;
  list:object[];
  id:string
  lengthOfList:number
  getFlag:boolean
  errorMessage:string
  taskErrorMessage:string
  receivedId:string
  receiveGiftMessage:string
  revealFlag:boolean
  
  name:string
  phoneNumber:string
  groupId:string
  myObj:object
  
  constructor(private ser:ChildService,private fp:FormBuilder, private activatedRoute:ActivatedRoute) { 
    this.id=null
    this.lengthOfList=null
    this.getFlag=false
    this.errorMessage=""
    this.receivedId=""
    this.revealFlag=false
    this.taskErrorMessage=null
  }

  ngOnInit() {
    
    this.name=null
    this.phoneNumber=null
    this.groupId=null

    this.activatedRoute.params.subscribe(params => { this.id = params['id']; });
    this.getFlag=false
  this.taskForm=this.fp.group({
  empId:[this.id,[Validators.required]]
})
  }

getTasks(){

this.taskErrorMessage=null
this.ser.getTasks(this.taskForm.value)
.then(a=>{this.list=a})
.catch(e=>this.taskErrorMessage=e[0].message)
}

revealSanta(){
  this.receivedId=null
  
  this.ser.revealSanta({empId:this.id})
  .then(
    a=>{
    this.receivedId=a.message
    
  })

  if(this.receivedId=="Not Completed"){
    this.revealFlag=true
    
  }
}

giftReceived(){
  this.ser.giftReceived({empId:this.id})
  .then(a=>this.receiveGiftMessage=a.message)
}

getDetails(){
  this.myObj=null
  this.name=null
  this.phoneNumber=null
  this.groupId=null
  
  this.ser.getDetails({empId:this.receivedId})
  .then(a=>{
    this.name=a.name
    this.phoneNumber=a.phoneNumber
    this.groupId=a.groupId

  })


}

}
