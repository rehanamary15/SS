import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable()
export class ChildService {

  constructor(private http:Http) { }

  getTasks(empid):Promise<any>{
    return this.http.post(environment.getTasks,empid)
    .toPromise()
    .then(a=>a.json() as string[])
    .catch(this.errorHandler)

  }

  revealSanta(empid):Promise<any>{
    return this.http.post(environment.revealSanta,empid)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)

  }

  giftReceived(data):Promise<any>
  {
    return this.http.post(environment.giftReceived,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  getDetails(data):Promise<any>
  {
    return this.http.post(environment.getDetails,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }


}
