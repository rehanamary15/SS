import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms/src/model';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { RegisterFormService } from '../register-form/register-form.service';
import { Router } from '@angular/router';
import {Output, EventEmitter } from '@angular/core';
import { LoginFormService } from './login-form.service';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  loginForm:FormGroup
  errorMessage:string
  successMessage:string
  id:string 
  organizer:boolean

  constructor(private fb:FormBuilder, private mySer:LoginFormService,private router:Router) {
    this.id=null
    this.organizer=false
   }

 @Output('notify') notify:EventEmitter<any> = new EventEmitter<any>();
 
  login()
  {
    var flag:boolean=true;
    this.notify.emit(flag);
    this.successMessage==null;
    this.errorMessage=null;
    this.organizer=false
    this.id=this.loginForm.controls.empId.value

    
      this.mySer.login(this.loginForm.value)
      .then( e=>{
        this.successMessage=e.message

        if(this.successMessage=='Success')
        this.router.navigate(['user-login',this.id,e.message])

        else if(this.successMessage=='admin')
        this.router.navigate(['admin'])

        else if(this.successMessage=='Organizer')
        this.router.navigate(['user-login',this.id,e.message,'organizer',this.id])
        
      })  
      .catch(e=>this.errorMessage=e.message)
   } 
  
  ngOnInit() {
    this.loginForm=this.fb.group({
      empId:["561658",[Validators.required,Validators.pattern("[0-9]{6}")]],
      password:["Kutty007#",[Validators.required]]
    })

  }


}

