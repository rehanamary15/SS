import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable()
export class LoginFormService {

  constructor(private http:Http) { }

  login(data) :Promise<any>{
    return this.http.post(environment.login,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)

  }

  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }

}
