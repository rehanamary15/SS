import { AbstractControl } from "@angular/forms";

export class NameValidator {
    static checkName(name: AbstractControl) {
       let enteredname=name.value;

       let namearr:string[]=enteredname.split(" ");
       for(let word of namearr){
          
           if(word.match("[a-zA-Z]+")){
               return null;
           }
           return {'checkName':true};
       }
    }
}