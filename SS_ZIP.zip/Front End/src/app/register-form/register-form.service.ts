import { Injectable } from '@angular/core';
import { Http, HttpModule } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../environments/environment';


@Injectable()
export class RegisterFormService {

  constructor(private http: Http) { }

  saveDetails(data) :Promise<any>{
    return this.http.post(environment.saveDetails,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)

  }


  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }

} 

