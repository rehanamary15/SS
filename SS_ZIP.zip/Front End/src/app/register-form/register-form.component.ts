import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegisterFormService } from './register-form.service';
import {Router} from '@angular/router';
import { DateValidator } from './date.Validator';
import { NameValidator } from './name.Validator';
import { CheckPasswordValidator } from './checkPassword.Validator';

@Component({
  selector: 'register-form-component',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent implements OnInit {

  pwdValidForm:FormGroup
  pwdValidForm1:FormGroup
  registerForm:FormGroup
  errorMessage:string
  successMessage:string

  constructor(private fb:FormBuilder, private mySer:RegisterFormService, private router:Router) { 
  }

  saveDetails()
  {
    this.successMessage=null
    this.errorMessage=null
    this.mySer.saveDetails(this.registerForm.value)
    .then(e=>this.successMessage=e.message)
    .catch(e=>this.errorMessage=e.message)
    
  }

  ngOnInit() {
    this.registerForm=this.fb.group({
      empId:["",[Validators.required, Validators.pattern("[0-9]{6}"),Validators.min(100000)]],
      name:["",[Validators.required, Validators.pattern("[a-zA-Z ]+"),NameValidator.checkName]],
      dateOfBirth:["",[Validators.required, DateValidator.checkDate]],
      groupId:["", [Validators.required]],
      phoneNumber:["",[Validators.required, Validators.pattern("[7-9][0-9]{9}")]],
      password:["",[Validators.required,Validators.pattern("(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@#^/\.,!%*?&-+_=<>{}:;~|`])[A-Za-z\d$@$!%*?&].{8,}")]]
              
    })
    this.pwdValidForm1=this.fb.group({
      
      cnfpassword:["",[Validators.required,Validators.pattern("(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@#^/\.,!%*?&-+_=<>{}:;~|`])[A-Za-z\d$@$!%*?&].{8,}")]]
    })

    
  }

}
