import { AbstractControl } from "@angular/forms";

export class CheckPasswordValidator {
    static checkPassword(password: AbstractControl):{invalid:boolean}{
        
        if(password.get('password').value!=password.get('cnfpassword').value){
            return {invalid:false}
        }
    }
}
