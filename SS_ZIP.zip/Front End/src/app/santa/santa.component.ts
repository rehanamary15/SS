import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { SantaServiceService } from './santa-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterFormService } from '../register-form/register-form.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-santa',
  templateUrl: './santa.component.html',
  styleUrls: ['./santa.component.css']
})
export class SantaComponent implements OnInit {

  santaForm:FormGroup
  successMessage:string
  successMessage2:string
  errorMessage:string
  savedTasks:string[]
  showCalled:boolean
  id:string
  taskIds:number[]
  task: object[]
  childId:object
  name:string
  phoneNumber:string
  groupId:string
  myObj:object
  santaTaskFlag:string

  constructor(private fb:FormBuilder, private obj:SantaServiceService, private activatedRoute:ActivatedRoute) { 
    this.savedTasks=new Array()
    this.id=null
    this.taskIds=new Array()
    this.showCalled=false
    this.successMessage=null
    this.successMessage2=null
    this.name=null
    this.phoneNumber=null
    this.groupId=null
    this.santaTaskFlag=null
    this.childId=null
    

  }

  ngOnInit() {

    this.activatedRoute.params.subscribe(params => { this.id = params['id']; });
  
    let b:any={"empId":this.id}
    
    this.obj.getChild(b)
    .then(a=>{
      this.childId=a[0]})
      
    this.santaForm=this.fb.group({
      taskDescription:["",Validators.pattern("[ ]*")],
      empId:[this.id,Validators.required]
    })

    this.getSantaTaskDetails()

  }

  saveTask()
  {
    this.successMessage=null

    this.obj.saveTask(this.santaForm.value)
    .then(a=>{
      this.showCalled=true
      this.successMessage=a.message
      this.getSantaTaskDetails()
      
    })
    .catch(e=>this.errorMessage=e.message)
  }

  getSantaTaskDetails()
  {
    this.santaTaskFlag=null
    

    this.obj.getSantaTaskDetails(this.santaForm.value)
    .then(a=>{
      this.task=a
      this.showCalled=true
    })

    
  }

  deleteTask(data)
  {
    let a:any={"taskId":data}
    
     this.obj.deleteTask(a)
    .then(a=>{
      this.successMessage2=a.message
      this.getSantaTaskDetails()})
  }

  getDetails(){
   

    this.obj.getDetails({empId:this.childId})
    .then(a=>{
      this.name=a.name
      this.phoneNumber=a.phoneNumber
      this.groupId=a.groupId

    })


  }
}
