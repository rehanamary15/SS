import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable()
export class SantaServiceService {

  constructor(private http:Http) { }

  saveTask(data):Promise<any>
  {
    return this.http.post(environment.saveTask,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }

  getSantaTaskDetails(data):Promise<any>
  {
    return this.http.post(environment.getSantaTaskDetails,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }

  deleteTask(data):Promise<any>
  {
    return this.http.post(environment.deleteTask,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  getChild(data):Promise<any>
  {
    return this.http.post(environment.getChild,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  
  getDetails(data):Promise<any>
  {
    return this.http.post(environment.getDetails,data)
    .toPromise()
    .then(a=>a.json() as any)
    .catch(this.errorHandler)
  }
  
  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }


}
