import { TestBed, inject } from '@angular/core/testing';

import { SantaServiceService } from './santa-service.service';

describe('SantaServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SantaServiceService]
    });
  });

  it('should be created', inject([SantaServiceService], (service: SantaServiceService) => {
    expect(service).toBeTruthy();
  }));
});
