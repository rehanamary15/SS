// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  login:"http://localhost:3333/EKart_Server/EmployeeAPI/login",

  assign:"http://localhost:3333/EKart_Server/AssignAPI/assign",

  showAll:"http://localhost:3333/EKart_Server/EmployeeAPI/showAll",

  assignOrganizer:"http://localhost:3333/EKart_Server/AssignOrganizer/assign",

  getChildSantaDetails:"http://localhost:3333/EKart_Server/AssignAPI/getChildSantaDetails",

  getFlagDetails:"http://localhost:3333/EKart_Server/FlagAPI/onInit",

  postFlagDetails:"http://localhost:3333/EKart_Server/FlagAPI/sendFlags",

  getOrganizerTasks:"http://localhost:3333/EKart_Server/TaskAPI/getOrganizerTasks",

  authenticateTask:"http://localhost:3333/EKart_Server/TaskAPI/authenticateTask",

  deleteTask:"http://localhost:3333/EKart_Server/TaskAPI/deleteTask",

  getDetails:"http://localhost:3333/EKart_Server/EmployeeAPI/getDetails",

  deleteAll:"http://localhost:3333/EKart_Server/AssignAPI/deleteAll",

  getTasks:"http://localhost:3333/EKart_Server/TaskAPI/getChildTask",

  revealSanta:"http://localhost:3333/EKart_Server/AssignAPI/revealSanta",

  giftReceived:"http://localhost:3333/EKart_Server/GiftAPI/giftReceived",

  allTasks:"http://localhost:3333/EKart_Server/TaskAPI/getAllTasks",

  getGiftHistory:"http://localhost:3333/EKart_Server/GiftAPI/getGiftHistory",

  saveDetails:"http://localhost:3333/EKart_Server/EmployeeAPI/saveDetails",

  saveTask:"http://localhost:3333/EKart_Server/TaskAPI/saveTask",

  getSantaTaskDetails:"http://localhost:3333/EKart_Server/TaskAPI/getSantaTask",

  getChild:"http://localhost:3333/EKart_Server/AssignAPI/getChildId",

  assignFlag:"http://localhost:3333/EKart_Server/FlagAPI/assignFlag"
  




};
