drop table EmployeeEntity;
drop table TaskEntity;
drop table ChildSantaEntity;
drop table FlagEntity;

create table EmployeeEntity (
empId varchar2(30) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
phoneNumber number(10) not null,
password varchar2(30) not null,
organizer varchar2(30),
groupId varchar2(10)
);



create table TaskEntity (
taskId varchar2(30) PRIMARY KEY,
taskDescription varchar2(90),
taskStatus varchar(30),
empId varchar2(30)
);


create table ChildSantaEntity (
childId varchar2(10) PRIMARY KEY,
santaId varchar2(10),
groupId varchar2(10),
giftStatus varchar2(20)
);

create table FlagEntity(
groupId varchar2(10) PRIMARY KEY,
flagvalue varchar2(19)
);
insert into FlagEntity values('A','true');
insert into FlagEntity values('B','true');
insert into FlagEntity values('C','true');
insert into FlagEntity values('assignFlag','true');


select * from FlagEntity;

select * from EmployeeEntity;
select * from TaskEntity;



select * from ChildSantaEntity;



