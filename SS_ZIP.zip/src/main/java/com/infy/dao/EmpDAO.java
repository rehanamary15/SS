package com.infy.dao;

import java.util.List;
import java.util.Map;

import com.infy.entity.EmployeeEntity;
import com.infy.model.AllTasks;
import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;



public interface EmpDAO {
	
	public void saveDetails(Employee emp) throws Exception;
	public EmployeeEntity login(Employee emp) throws Exception;
	public void saveTask(Task t) throws Exception;
	public List<Task> getChildTask(Task t) throws Exception;
	public void assign() throws Exception;
	public void deleteTask(Task t);
	public List<ChildSanta> getChildSantaDetails(String groupId) throws Exception;
	public List<Task> getSantaTask(Task t) throws Exception;
	public void authenticateTask(Task t);
	public void assignOrganizer(Employee emp);
	public List<AllTasks> getAllTasks(Employee emp);
	public Map<String,List<Employee>> showAll() throws Exception;
	public Map<String,String> sendFlags(String groupId) ;
	public Map<String,String> onInit();
	
	public String revealSanta(Employee child);
	public void giftReceived(Employee child);
	public List<ChildSanta> getGiftHistory(Employee emp);
	public List<AllTasks> getOrganizerTask();
	public List<String> getChildId(Employee child);
	public Employee getDetails(Employee emp);
	public Map<String, String> assignFlag();
	public void deleteGroup();

}
