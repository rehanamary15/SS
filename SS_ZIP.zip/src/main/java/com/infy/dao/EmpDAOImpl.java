package com.infy.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.EmployeeEntity;
import com.infy.entity.FlagEntity;
import com.infy.entity.TaskEntity;
import com.infy.entity.ChildSantaEntity;
import com.infy.model.AllTasks;
import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;


@Repository("dao")
public class EmpDAOImpl implements EmpDAO {
	

	@Autowired
	SessionFactory sessionFactory;
	
	Session session;

	@Override
	public void saveDetails(Employee emp) throws Exception{
		
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity empEntity = new EmployeeEntity();
		
		EmployeeEntity ee =session.get(EmployeeEntity.class,emp.getEmpId());
		if(ee==null){
			empEntity.setName(emp.getName());
			empEntity.setEmpId(emp.getEmpId());
			empEntity.setDateOfBirth(emp.getDateOfBirth());
			empEntity.setPhoneNumber(emp.getPhoneNumber());
			empEntity.setPassword(emp.getPassword());
			empEntity.setGroup(emp.getGroupId());
			empEntity.setOrganizer("None");
			session.persist(empEntity);
		}
		else{
			throw new Exception("Employee Id already exists");
			}
				
	}
	
	
	@Override
	public void saveTask(Task t) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		TaskEntity tEntity = new TaskEntity();
		tEntity.setEmpId(t.getEmpId());
		tEntity.setTaskDescription(t.getTaskDescription());
		tEntity.setTaskId(t.getTaskId());
		tEntity.setTaskStatus("Not started yet");
		session.persist(tEntity);
		// TODO Auto-generated method stub
		
	}
	@Override
	public EmployeeEntity login(Employee emp) throws Exception {
		
		String empId=emp.getEmpId();
		
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity log=new EmployeeEntity();
		
		log=session.get(EmployeeEntity.class, empId);
		return log;
//		try{
//		if(log==null)
//			throw new Exception("Service.invalidEmpid");
//		else{
//			if(!log.getPassword().equals(password))
//				throw new Exception("Service.invalidPassword");
//		}}catch(Exception e){
//			System.out.println(e.getMessage());
//			throw e;
//		}
		
		
		
	}
	@Override
	public List<Task> getChildTask(Task t) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery
		("select t.taskDescription from TaskEntity t inner join ChildSantaEntity cs on t.empId=cs.santaId where cs.childId="+t.getEmpId());
		List<Task> tasks = query.getResultList();
		return tasks;
	}
	

	@Override
	public List<Task> getSantaTask(Task t) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery
		("select taskId,taskDescription,taskStatus from TaskEntity where empId="+t.getEmpId());
		
		List<Task> tasks = query.getResultList();
		return tasks;
	}



@Override
	public void assign() throws Exception {
		String groups[]={"A","B","C"};
		int count=0;
		String querys[]={"select empId from EmployeeEntity where groupId='A'","select empId from EmployeeEntity where groupId='B'","select empId from EmployeeEntity where groupId='C'"};
		Session session = sessionFactory.getCurrentSession();
		for(int no=0;no<3;no++){
		Query query = session.createQuery(querys[no]);
		
		ArrayList<String> childId = (ArrayList<String>) query.getResultList();
		
		if(childId.size()>=2)
		{
			count++;
		 ArrayList<String>  santaId = new ArrayList<String>();
		 
		 for (String id : childId) 
	        { 		      
	            	santaId.add(id);	
	        }
	        Collections.shuffle(childId);
	        
	        while(true)
	        {
	            if(EmpDAOImpl.check(childId,santaId)==true)
	                break;
	            else
	                Collections.shuffle(childId); 
	                
	        }
	        
	        
	        for (int counter = 0; counter < childId.size(); counter++) 
	        { 		      
	         ChildSantaEntity row=new ChildSantaEntity();
	         row.setSantaId(santaId.get(counter));
	         row.setChildId(childId.get(counter));
	         row.setGroupId(groups[no]);
	         row.setGiftStatus("Not received yet");
	         session.persist(row);
	        }
		}
}
		if(count==0){
			throw new Exception("No players in all the 3 groups");
		}
	  
		
	}



public static boolean check(ArrayList mylist,ArrayList original)
{
     for (int counter = 0; counter < mylist.size(); counter++) 
    { 		      
     if(mylist.get(counter)==original.get(counter))
        {
         return false;
        }
    }
    return true;
}
@Override
public void deleteTask(Task t) {
	Session session = sessionFactory.getCurrentSession();
	TaskEntity task = session.get(TaskEntity.class, t.getTaskId());
    session.delete(task);
	
	
}

@Override
public List<ChildSanta> getChildSantaDetails(String groupId) throws Exception {
	Session session = sessionFactory.getCurrentSession();
	if(groupId.equals("A"))
	{
		Query query = session.createQuery("select santaId, childId from ChildSantaEntity where groupId='A'");
		List<ChildSanta> childSantas = query.getResultList();
		return childSantas;

	}
	else if(groupId.equals("B"))
	{
		Query query = session.createQuery("select santaId, childId from ChildSantaEntity where groupId='B'");
		List<ChildSanta> childSantas = query.getResultList();
		return childSantas;

	}
	else
	{
		Query query = session.createQuery("select santaId, childId from ChildSantaEntity where groupId='C'");
		List<ChildSanta> childSantas = query.getResultList();
		return childSantas;

	}
	}


@Override
public void authenticateTask(Task t) {
	
	Session session = sessionFactory.getCurrentSession();
	TaskEntity task = session.get(TaskEntity.class, t.getTaskId());
	task.setTaskStatus("Completed");
	
	
	
}


@Override
public void assignOrganizer(Employee emp) {
	Session session = sessionFactory.getCurrentSession();
	EmployeeEntity employee = session.get(EmployeeEntity.class, emp.getEmpId());
	employee.setOrganizer("Organizer");
	
}


@Override
public Map<String,List<Employee>> showAll() throws Exception {
	Session session = sessionFactory.getCurrentSession();
	Query query = session.createQuery("select empId from EmployeeEntity where groupId='A'");
	List<Employee> groupA = query.getResultList();
	
	Query query1 = session.createQuery("select empId from EmployeeEntity where groupId='B'");
	List<Employee> groupB = query1.getResultList();
	
	Query query2 = session.createQuery("select empId from EmployeeEntity where groupId='C'");
	List<Employee> groupC = query2.getResultList();
	
	Map<String, List<Employee>> employeeGroups=new HashMap<>();
	employeeGroups.put("A", groupA);
	employeeGroups.put("B", groupB);
	employeeGroups.put("C", groupC);
	return employeeGroups;
}


@Override
public List<AllTasks> getAllTasks(Employee emp) {
	
	Session session = sessionFactory.getCurrentSession();
	Query query = session.createQuery
			("select te.taskId,cse.childId,te.taskStatus,te.taskDescription,cse.santaId from TaskEntity te inner join ChildSantaEntity cse on te.empId=cse.santaId where cse.groupId=(select groupId from EmployeeEntity where empId='"+emp.getEmpId()+"')");
	List<AllTasks> allTasks = query.getResultList();
	return allTasks;
}


@Override
public Map<String, String> sendFlags(String groupId) {
	Session session = sessionFactory.getCurrentSession();
	FlagEntity flag = session.get(FlagEntity.class,groupId);
	flag.setFlagValue("false");
	
	
	
	
	Map<String, String> flagGroups=new HashMap<>();
	flag = session.get(FlagEntity.class,"A");
	flagGroups.put("A", flag.getFlagValue());
	flag = session.get(FlagEntity.class,"B");
	flagGroups.put("B", flag.getFlagValue());
	flag = session.get(FlagEntity.class,"C");
	flagGroups.put("C", flag.getFlagValue());
	
	return flagGroups; 
}


@Override
public Map<String, String> onInit() {
	session = sessionFactory.getCurrentSession();
	
	
	Map<String, String> flagGroups=new HashMap<>();
	
	FlagEntity flag = session.get(FlagEntity.class,"A");
	flagGroups.put("A", flag.getFlagValue());
	flag = session.get(FlagEntity.class,"B");
	flagGroups.put("B", flag.getFlagValue());
	flag = session.get(FlagEntity.class,"C");
	flagGroups.put("C", flag.getFlagValue());
	flag = session.get(FlagEntity.class,"assignFlag");
	flagGroups.put("assignFlag", flag.getFlagValue());
	
	return flagGroups; 
	
}


@Override
public String revealSanta(Employee child) {
	Session session = sessionFactory.getCurrentSession();
	Query query1 = session.createQuery
			("select te.taskStatus from TaskEntity te inner join ChildSantaEntity cse on cse.santaId=te.empId where cse.childId='"+child.getEmpId()+"' and te.taskStatus='Completed'");
	List<String> taskCompleted = query1.getResultList();
	Query query2 = session.createQuery
			("select te.taskStatus from TaskEntity te inner join ChildSantaEntity cse on cse.santaId=te.empId where cse.childId='"+child.getEmpId()+"'");
	List<String> taskStatus = query2.getResultList();
	
	if((taskCompleted.size()==taskStatus.size())&&taskStatus.size()!=0)
	{
		ChildSantaEntity cse=session.get(ChildSantaEntity.class, child.getEmpId());
		return cse.getSantaId();
	}
	else
		return "Not Completed";
	
	
	
	
}


@Override
public void giftReceived(Employee child) {
	
	Session session = sessionFactory.getCurrentSession();
	ChildSantaEntity cse= session.get(ChildSantaEntity.class, child.getEmpId());
	cse.setGiftStatus("Received");
	
}


@Override
public List<ChildSanta> getGiftHistory(Employee emp) {
	
	Session session = sessionFactory.getCurrentSession();
	Query query = session.createQuery
			("select childId,santaId,giftStatus from ChildSantaEntity where groupId=(select groupId from EmployeeEntity where empId='"+emp.getEmpId()+"')");
	List<ChildSanta> gifts = query.getResultList();
	return gifts;
	
}


@Override
public List<AllTasks> getOrganizerTask() {
	Session session = sessionFactory.getCurrentSession();
	List<AllTasks> allTasks = null;
	List<AllTasks> organizerTasks=new ArrayList<>();
	Query query1 = session.createQuery
			("select empId from EmployeeEntity where organizer='Organizer'");
	List<String> organizers = query1.getResultList();
	for(String organizer:organizers){
		Query query2 = session.createQuery
				("select te.taskId,cse.santaId,te.taskStatus,te.taskDescription from TaskEntity te inner join ChildSantaEntity cse on cse.santaId=te.empId where cse.santaId='"+organizer+"'");
		 allTasks = query2.getResultList();
		 organizerTasks.addAll(allTasks);
	}
	return organizerTasks;
	
}


@Override
public List<String> getChildId(Employee child) {
	// TODO Auto-generated method stub
	Session session = sessionFactory.getCurrentSession();
	Query query1 = session.createQuery
			("select childId from ChildSantaEntity where santaId='"+child.getEmpId()+"'");
	List<String> a= query1.getResultList();
	return a;
}


@Override
public Employee getDetails(Employee emp) {
	Session session = sessionFactory.getCurrentSession();
	EmployeeEntity ee= session.get(EmployeeEntity.class, emp.getEmpId());
	Employee e=new Employee();
	e.setDateOfBirth(ee.getDateOfBirth());
	e.setEmpId(ee.getEmpId());
	e.setGroupId(ee.getGroup());
	e.setName(ee.getName());
	e.setPhoneNumber(ee.getPhoneNumber());
	
	return e;
	
}


@Override
public Map<String, String> assignFlag() {
	session = sessionFactory.getCurrentSession();
	
	FlagEntity flag = session.get(FlagEntity.class,"assignFlag");
	flag.setFlagValue("false");
	Map<String, String> flagGroups=new HashMap<>();
	
	flagGroups.put("assignFlag", flag.getFlagValue());
	
	return flagGroups;
	
}


@Override
public void deleteGroup() {
	Session session = sessionFactory.getCurrentSession();
	String querys[]={"delete from ChildSantaEntity","delete from EmployeeEntity","delete from FlagEntity",
			"delete from TaskEntity"
			
	};
	
	Query query; 
	for(String query1:querys){
		query= session.createQuery(query1);
	query.executeUpdate();
	}
	
	FlagEntity fe=new FlagEntity();
	
	fe.setGroupId("A");
	fe.setFlagValue("true");
	session.persist(fe);
	
	FlagEntity fe1=new FlagEntity();
	fe1.setGroupId("B");
	fe1.setFlagValue("true");
	session.persist(fe1);
	
	FlagEntity fe2=new FlagEntity();
	fe2.setGroupId("C");
	fe2.setFlagValue("true");
	session.persist(fe2);
	
	FlagEntity fe3=new FlagEntity();
	fe3.setGroupId("assignFlag");
	fe3.setFlagValue("true");
	session.persist(fe3);
	
	
	
}



	

	

	
}

