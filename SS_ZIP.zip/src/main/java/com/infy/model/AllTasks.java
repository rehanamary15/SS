package com.infy.model;



public class AllTasks {
	
	
	private String childId;
	private String santaId;
	private String taskDescription;
	private String taskStatus;
	
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	private String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getChildId() {
		return childId;
	}
	public void setChildId(String childId) {
		this.childId = childId;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public String getSantaId() {
		return santaId;
	}
	public void setSantaId(String santaId) {
		this.santaId = santaId;
	}
	
	
}