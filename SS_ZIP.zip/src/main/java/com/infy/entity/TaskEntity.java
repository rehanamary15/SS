package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
@GenericGenerator(name = "pkgen", strategy = "increment")
public class TaskEntity {
	
	@Id
	@GeneratedValue(generator = "pkgen")
	private Integer taskId;
	private String empId;
	private String taskDescription;
	private String taskStatus;
	
	
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer s) {
		this.taskId = s;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	
	

	
	

}