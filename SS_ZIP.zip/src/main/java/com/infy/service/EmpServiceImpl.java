package com.infy.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.EmpDAO;
import com.infy.entity.EmployeeEntity;
import com.infy.model.AllTasks;
import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;

@Service("EmpService")
@Transactional(readOnly = true)
public class EmpServiceImpl implements EmpService {
	
	
	@Autowired
	private EmpDAO dao;

	@Transactional(readOnly = false)
	public void saveDetails(Employee emp) throws Exception {

		try {
			dao.saveDetails(emp);
		} catch (Exception e) 
		{
			throw e;
		}

	}

	@Transactional(readOnly = false)
	public String login(Employee emp) throws Exception {
		String value;
		if (emp.getEmpId().length() == 0 || emp.getPassword().length() == 0)
			throw new Exception("Service.emptyFields");
		try {
			EmployeeEntity log = dao.login(emp);
			
				
			if (log == null)
				throw new Exception("Service.invalidEmpid");
			else {
				if (!log.getPassword().equals(emp.getPassword()))
					throw new Exception("Service.invalidPassword");
			}
			if(log.getOrganizer().equals("Organizer"))
			{
				 value="Organizer";
			}
			else
				 value="Success";
			return value;

		}
		catch (Exception e) {

			throw e;
		}

	}

	@Transactional(readOnly = false)
	public void saveTask(Task t) throws Exception {

		dao.saveTask(t);
	}

	@Override
	public List<Task> getChildTask(Task t) throws Exception {
		if(dao.getChildTask(t).size()<=0)
			throw new Exception("No tasks assigned yet");
		
		else
		
			return dao.getChildTask(t);
	}

	@Transactional(readOnly = false)
	public void assign() throws Exception {
		dao.assign();

	}
	
	@Override
	public List<Task> getSantaTask(Task t) throws Exception {
		
			return dao.getSantaTask(t);
	}

	@Transactional(readOnly = false)
	public void deleteTask(Task t) {
		// TODO Auto-generated method stub
		dao.deleteTask(t);
	}

	@Override
	public List<ChildSanta> getChildSantaDetails(String groupId) throws Exception {
		if(dao.getChildSantaDetails(groupId).size()<2)
				throw new Exception("Not enough players! Sorry");
		else
			return dao.getChildSantaDetails(groupId);
	}

	@Override
	@Transactional(readOnly = false)
	public void authenticateTask(Task t) {
		dao.authenticateTask(t);
		
	}
	
	@Transactional(readOnly = false)
	public void assignOrganizer(Employee emp) {
		dao.assignOrganizer(emp);
		
	}

	@Override
	public Map<String,List<Employee>> showAll() throws Exception {
		Map<String,List<Employee>> groupMap=dao.showAll();
		if(groupMap.get("A").size()==0 && groupMap.get("B").size()==0 && groupMap.get("C").size()==0)
			throw new Exception("No players,Sorry");
		return groupMap;
	}

	@Override
	public List<AllTasks> getAllTasks(Employee emp) throws Exception {
		if(dao.getAllTasks(emp).size()==0)
		{
			throw new Exception("No tasks Found");
			
		}
		return dao.getAllTasks(emp);
		
	}

	@Transactional(readOnly = false)
	public Map<String, String> sendFlags(String groupId)  {
		return dao.sendFlags(groupId);
		
	}

	@Override
	public Map<String, String> onInit() {
		return dao.onInit();
	}

	@Override
	public String revealSanta(Employee child) {
		return dao.revealSanta(child);
	}
	
	@Transactional(readOnly = false)
	public void giftReceived(Employee child) {
		
		dao.giftReceived(child);
		
		
	}

	public List<ChildSanta> getGiftHistory(Employee emp) {
		return dao.getGiftHistory(emp);
	}

	public List<AllTasks> getOrganizerTasks() throws Exception{
		if(dao.getOrganizerTask().size()==0)
			throw new Exception("No tasks found");
		return dao.getOrganizerTask();
	}

	public List<String> getChildId(Employee santa) {
		// TODO Auto-generated method stub
		return dao.getChildId(santa);

	}

	public Employee getDetails(Employee emp) {
		return dao.getDetails(emp);
	}
	
	
	@Transactional(readOnly = false)
	public Map<String, String> assignFlag() {
			return dao.assignFlag();
	}
	
	@Transactional(readOnly = false)
	public void deleteGroup() {
		dao.deleteGroup();
	}

}