package com.infy.service;



import java.util.List;
import java.util.Map;

import com.infy.model.AllTasks;
import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;



public interface EmpService {
	
	public void saveDetails(Employee emp) throws Exception;
	public String login(Employee emp) throws Exception;
	public void saveTask(Task t) throws Exception;
	public List<Task> getChildTask(Task t) throws Exception;
	public void assign() throws Exception;
	public void deleteTask(Task t);
	public void authenticateTask(Task t);
	public List<ChildSanta> getChildSantaDetails(String groupId) throws Exception;
	public List<Task> getSantaTask(Task t) throws Exception;
	public void assignOrganizer(Employee emp); 
	public List<AllTasks> getAllTasks(Employee emp) throws Exception;
	public Map<String,List<Employee>> showAll() throws Exception;
	public Map<String,String> sendFlags(String groupId);
	public Map<String,String> onInit();
	public String revealSanta(Employee childId);
	public void giftReceived(Employee child);
	public List<ChildSanta> getGiftHistory(Employee emp);
	public List<AllTasks> getOrganizerTasks() throws Exception;
	
}
