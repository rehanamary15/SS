package com.infy.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;
import com.infy.service.EmpServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("AssignAPI")
public class AssignSanta {
	
	
	
	@RequestMapping(value="assign",method=RequestMethod.GET)
	public ResponseEntity<Employee> assign(){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Environment env=ContextFactory.getContext().getEnvironment();
		Employee emp=new Employee();
		
		try {
			empImpl.assign();
			emp.setMessage("successfully assigned santas for the players");
			ResponseEntity<Employee> res=new ResponseEntity<>(emp,HttpStatus.OK);
			return res;
		} catch (Exception e) {

			emp.setMessage(e.getMessage());
			ResponseEntity<Employee> res=new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			return res;
		}
		
		
		
	}
	
	@RequestMapping(value="getChildSantaDetails",method=RequestMethod.POST)
	public ResponseEntity<List<ChildSanta>> getChildSantaDetails(@RequestBody String groupId){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<List<ChildSanta>> res = null;
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			List<ChildSanta> childSantas = empImpl.getChildSantaDetails(groupId);
			
			res=new ResponseEntity<>(childSantas,HttpStatus.OK);
			return res;
		} catch (Exception e) 
		{
			ChildSanta cs=new ChildSanta();
			List<ChildSanta> childSantas=new ArrayList<>();
			cs.setGiftStatus(e.getMessage());
			childSantas.add(cs);
			res=new ResponseEntity<>(childSantas,HttpStatus.BAD_REQUEST);
			return res;
		}
		
	}
	
	@RequestMapping(value="revealSanta",method=RequestMethod.POST)
	public ResponseEntity<Employee> revealSanta(@RequestBody Employee child){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<Employee> res = null;
		
		
			String message=empImpl.revealSanta(child);
			child.setMessage(message);
			res=new ResponseEntity<>(child,HttpStatus.OK);
			return res;
		 
		
	}
	
	@RequestMapping(value="getChildId",method=RequestMethod.POST)
	public ResponseEntity<List<String>> getChildId(@RequestBody Employee santa){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<List<String>> res = null;
		List<String> message=empImpl.getChildId(santa);
			
			res=new ResponseEntity<>(message,HttpStatus.OK);
			return res;
		
	}

	@RequestMapping(value="deleteAll",method=RequestMethod.GET)
	public ResponseEntity<Employee> deleteGroup(){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<Employee> res = null;
			empImpl.deleteGroup();
			Employee e=new Employee();
			e.setMessage("Successfully deleted");
			res=new ResponseEntity<>(e,HttpStatus.OK);
			return res;
		
	}
	
	
}
