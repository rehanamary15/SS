package com.infy.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.AllTasks;
import com.infy.model.Employee;
import com.infy.model.Task;
import com.infy.service.EmpServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("TaskAPI")
public class TaskAPI {
	
	
	
	@RequestMapping(value="saveTask",method=RequestMethod.POST)
	public ResponseEntity<Task> saveTask(@RequestBody Task t){
		ResponseEntity<Task> res1;
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Environment env=ContextFactory.getContext().getEnvironment();
		try {
			empImpl.saveTask(t);
			
			t.setMessage(env.getProperty("Service.TaskAddedSuccessfully"));
			 res1=new ResponseEntity<>(t,HttpStatus.OK);
		} catch (Exception e) {
			t.setMessage(env.getProperty("Service.TaskFailure"));
			res1=new ResponseEntity<>(t,HttpStatus.BAD_REQUEST);
		}
		
		
		
		return res1;
	}
	
	@RequestMapping(value="getChildTask",method=RequestMethod.POST)
	public ResponseEntity<List<Task>> getTask(@RequestBody Task t){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<List<Task>> res = null;
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			List<Task> tasks=empImpl.getChildTask(t);
			res=new ResponseEntity<>(tasks,HttpStatus.OK);
			return res;
		} catch (Exception e) 
		{
			List<Task> tasks=new ArrayList<>();
			Task a =new Task();
			a.setMessage(e.getMessage());
			tasks.add(a);
			res=new ResponseEntity<>(tasks,HttpStatus.BAD_REQUEST);
			return res;
		}

	}
	
	@RequestMapping(value="getSantaTask",method=RequestMethod.POST)
	public ResponseEntity<List<Task>> getSantaTask(@RequestBody Task t){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<List<Task>> res = null;
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			List<Task> tasks=empImpl.getSantaTask(t);
			res=new ResponseEntity<>(tasks,HttpStatus.OK);
			
		} catch (Exception e) 
		{
//			List<Task> tasks=new ArrayList<>();
//			Task a =new Task();
//			a.setMessage(e.getMessage());
//			tasks.add(a);
//			res=new ResponseEntity<>(tasks,HttpStatus.BAD_REQUEST);
//			return res;
		}
		return res;
	}
	
	@RequestMapping(value="deleteTask",method=RequestMethod.POST)
	public ResponseEntity<Employee> deleteTask(@RequestBody Task t){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<Employee> res = null;
		Employee e=new Employee();
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			empImpl.deleteTask(t);
			e.setMessage("Successfully Deleted the task");
			res=new ResponseEntity<>(e,HttpStatus.OK);
			return res;
		} catch (Exception ee) 
		{
		}
		return res;
		
	}
	
	@RequestMapping(value="authenticateTask",method=RequestMethod.POST)
	public ResponseEntity<Employee> authenticateTask(@RequestBody Task t){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<Employee> res = null;
		Employee e=new Employee();
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			empImpl.authenticateTask(t);
			e.setMessage("Successfully authenticated the task");
			res=new ResponseEntity<>(e,HttpStatus.OK);
			return res;
		} catch (Exception ee) 
		{
		}
		return res;
		
	}
	
	@RequestMapping(value="getAllTasks",method=RequestMethod.POST)
	public ResponseEntity<List<AllTasks>> getAllTasks(@RequestBody Employee emp){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<List<AllTasks>> res = null;
		Employee e=new Employee();
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			List<AllTasks> tasks=empImpl.getAllTasks(emp);
			
			res=new ResponseEntity<>(tasks,HttpStatus.OK);
			return res;
		} catch (Exception ee) 
		{

			List<AllTasks> tasks=new ArrayList<>();
			AllTasks a=new AllTasks();
			a.setMessage(ee.getMessage());
			tasks.add(a);
			
			res=new ResponseEntity<>(tasks,HttpStatus.BAD_REQUEST);
			return res;
		}
		
	}
	
	
	@RequestMapping(value="getOrganizerTasks",method=RequestMethod.GET)
	public ResponseEntity<List<AllTasks>> getOrganizerTasks(){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<List<AllTasks>> res = null;
		Employee e=new Employee();
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			List<AllTasks> tasks=empImpl.getOrganizerTasks();
			
			
			res=new ResponseEntity<>(tasks,HttpStatus.OK);
			return res;
		} catch (Exception ee) 
		
		{
			AllTasks allTasks = new AllTasks();
			allTasks.setMessage(ee.getMessage());
			List<AllTasks> tasks = new ArrayList<>();
			tasks.add(allTasks);
			res = new ResponseEntity<>(tasks,HttpStatus.BAD_REQUEST);
		}
		return res;
		
	}
	
	
	
	
}
