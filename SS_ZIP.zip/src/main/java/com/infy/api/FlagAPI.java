package com.infy.api;

import java.util.List;
import java.util.Map;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;
import com.infy.service.EmpServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("FlagAPI")
public class FlagAPI {
	
	
	
	@RequestMapping(value="sendFlags",method=RequestMethod.POST)
	public ResponseEntity<Map<String,String>> sendFlags(@RequestBody Employee groupId){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Environment env=ContextFactory.getContext().getEnvironment();
		Map<String,String> flags;
		
		
		flags=empImpl.sendFlags(groupId.getGroupId());
			
		ResponseEntity<Map<String,String>> res=new ResponseEntity<>(flags,HttpStatus.OK);
		return res;
		
	}
	
	
	
	@RequestMapping(value="onInit",method=RequestMethod.GET)
	public ResponseEntity<Map<String,String>> onInit(){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Environment env=ContextFactory.getContext().getEnvironment();
		Map<String,String> flags;
		
		
		flags=empImpl.onInit();
			
		ResponseEntity<Map<String,String>> res=new ResponseEntity<>(flags,HttpStatus.OK);
		return res;
		
	}
	
	@RequestMapping(value="assignFlag",method=RequestMethod.GET)
	public ResponseEntity<Map<String,String>> assignFlag(){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Environment env=ContextFactory.getContext().getEnvironment();
		Map<String,String> flags;
		
		
		flags=empImpl.assignFlag();
			
		ResponseEntity<Map<String,String>> res=new ResponseEntity<>(flags,HttpStatus.OK);
		return res;
		
	}
	
	
	
	
	
	
}
