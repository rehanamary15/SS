package com.infy.api;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.AllTasks;
import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;
import com.infy.service.EmpServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("GiftAPI")
public class GiftAPI {
	
	
	
	@RequestMapping(value="giftReceived",method=RequestMethod.POST)
	public ResponseEntity<Employee> saveTask(@RequestBody Employee child){
		ResponseEntity<Employee> res1;
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		
			empImpl.giftReceived(child);
			child.setMessage("Thank you for confirming!");
			res1=new ResponseEntity<>(child,HttpStatus.OK);
		
		return res1;
		
}
	
	@RequestMapping(value="getGiftHistory",method=RequestMethod.POST)
	public ResponseEntity<List<ChildSanta>> getGiftHistory(@RequestBody Employee emp){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<List<ChildSanta>> res = null;
		Employee e=new Employee();
		
		try 
		{
			List<ChildSanta> gifts=empImpl.getGiftHistory(emp);
			
			res=new ResponseEntity<>(gifts,HttpStatus.OK);
			return res;
		} catch (Exception ee) 
		{}
		return res;
		
	}
	
	
}
