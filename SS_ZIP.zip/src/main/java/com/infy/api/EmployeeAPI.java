package com.infy.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;
import com.infy.service.EmpServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("EmployeeAPI")
public class EmployeeAPI {
	
	
	ResponseEntity<Employee> res;
	@RequestMapping(value="saveDetails",method=RequestMethod.POST)
	public ResponseEntity<Employee> saveDetails(@RequestBody Employee emp){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<Employee> res=null;
		try {
			empImpl.saveDetails(emp);
			Environment env=ContextFactory.getContext().getEnvironment();
			emp.setMessage(env.getProperty("Service.AddedSuccessfully"));
			res=new ResponseEntity<>(emp,HttpStatus.OK);
		} catch (Exception e) {
			Environment env=ContextFactory.getContext().getEnvironment();
			emp.setMessage(e.getMessage());
			res=new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
		}
				
		return res;
	}
	
		
	@RequestMapping(value="login",method=RequestMethod.POST)
	public ResponseEntity<Employee> login(@RequestBody Employee emp){
		
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		try{
			if(emp.getEmpId().equals("100000") && emp.getPassword().equals("admin"))
			{
				emp.setMessage("admin");
				res=new ResponseEntity<>(emp,HttpStatus.OK);
			}
			else{
		
		String value=empImpl.login(emp);
		emp.setMessage(value);
		
		res=new ResponseEntity<>(emp,HttpStatus.OK);
			}
		}
		catch(Exception e)
		{
		Environment env=ContextFactory.getContext().getEnvironment();
		emp.setMessage(env.getProperty(e.getMessage()));
		res=new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
		}
		return res;
	}
	
	@RequestMapping(value="showAll",method=RequestMethod.GET)
	public ResponseEntity<Map<String,List<Employee>>> showAll(){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<Map<String,List<Employee>>> res = null;
		Environment env=ContextFactory.getContext().getEnvironment();
		try 
		{
			Map<String,List<Employee>> employees = new HashMap<>(); 
			employees=empImpl.showAll();
			res=new ResponseEntity<>(employees,HttpStatus.OK);
			return res;
		} catch (Exception e) 
		{
			Map<String,List<Employee>> employees = new HashMap<>();
			Employee ee=new Employee();
			ee.setMessage(e.getMessage());
			List<Employee> listEmployee=new ArrayList<Employee>();
			listEmployee.add(ee);
			employees.put("error",listEmployee);
			res=new ResponseEntity<>(employees,HttpStatus.BAD_REQUEST);
			return res;
		}
		
	}
	
	@RequestMapping(value="getDetails",method=RequestMethod.POST)
	public ResponseEntity<Employee> getDetails(@RequestBody Employee emp){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ResponseEntity<Employee> res = null;
		Environment env=ContextFactory.getContext().getEnvironment();
		
			 
			Employee employee=empImpl.getDetails(emp);
			res=new ResponseEntity<>(employee,HttpStatus.OK);
			return res;
		 
		
	}
	
	
	
}
