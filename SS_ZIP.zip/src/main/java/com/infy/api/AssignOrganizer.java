package com.infy.api;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;
import com.infy.service.EmpServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("AssignOrganizer")
public class AssignOrganizer {
	
	
	
	@RequestMapping(value="assign",method=RequestMethod.POST)
	public ResponseEntity<Employee> assign(@RequestBody Employee emp){
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Environment env=ContextFactory.getContext().getEnvironment();
		
		
		try {
			empImpl.assignOrganizer(emp);
			emp.setMessage("Organizer assigned successfully");
			
		} catch (Exception e) {

			emp.setMessage("Failed to assign organizer!");
		}
		
		
		ResponseEntity<Employee> res=new ResponseEntity<>(emp,HttpStatus.OK);
		return res;
	}
	
	
	
}
