package com.infy.test.DAO;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Repository;

import com.infy.configuration.SpringConfig;
import com.infy.dao.EmpDAOImpl;
import com.infy.entity.EmployeeEntity;
import com.infy.model.AllTasks;
import com.infy.model.ChildSanta;
import com.infy.model.Employee;
import com.infy.model.Task;
import com.infy.service.EmpServiceImpl;
import com.infy.utility.ContextFactory;
@Repository("test")
public class DAOTesting {
	@Autowired
	SessionFactory sessionFactory;
	
	Session session;
	@Rule
    public ExpectedException ee = ExpectedException.none();
	@Test
	public void saveDetailsTest() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		
		
		Employee e=new Employee();
		LocalDate ld=LocalDate.of(1997, 11, 22);
		e.setEmpId("561657");
		e.setGroupId("A");
		e.setName("Raghav S");
		e.setDateOfBirth(ld);
		e.setPassword("Kutty007#");
		e.setPhoneNumber("8807961558");
		
		ee.expect(Exception.class);
		ee.expectMessage("Employee Id already exists");
		
		
		empImpl.saveDetails(e);
		
		
		
		
		}
	@Test
	public void loginEmptyEmpIdTest() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		
		
		Employee e=new Employee();
		
		e.setEmpId("");
		
		e.setPassword("Kutty007#");
		
		ee.expect(Exception.class);  
		ee.expectMessage("Service.emptyFields");
		empImpl.login(e);
		
		
		
		
		}
	
	
	@Test
	public void loginEmptyPasswordTest() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		
		
		Employee e=new Employee();
		
		e.setEmpId("561657");
		
		e.setPassword("");
		
		ee.expect(Exception.class);  
		ee.expectMessage("Service.emptyFields");
		empImpl.login(e);
		
		
		
		
		}
	@Test
	public void loginWrongPassword() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		
		
		Employee e=new Employee();
		
		e.setEmpId("561657");
		
		e.setPassword("Kutty007&sd");
		
		ee.expect(Exception.class);  
		ee.expectMessage("Service.invalidPassword");
		empImpl.login(e);
		
		
		
		
		}
	
	@Test
	public void correctLoginTest() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Employee emp=new Employee();
		emp.setEmpId("561657");
		emp.setPassword("Kutty007#");
		

		
		String ee= empImpl.login(emp);
		assertEquals("Success",ee);
		
		
		
		
		
		
		
		}
	
	@Test
	public void correctOrganizerTest() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Employee emp=new Employee();
		emp.setEmpId("561658");
		emp.setPassword("Kutty007#");
		
		String ee= empImpl.login(emp);
		assertEquals("Organizer",ee);
		
		
		
		
		
		
		
		}
	
//	@Test
//	public void santaTaskTest() throws Exception {
//		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
//		Employee emp=new Employee();
//		Task t=new Task();
//		t.setEmpId("561658");
//		Task task1=new Task();
//		task1.setTaskId(1);
//		task1.setTaskDescription("Do pushups");
//		task1.setTaskStatus("Not started yet");
//		
//		Task task2=new Task();
//		task1.setTaskId(2);
//		task1.setTaskDescription("Do pullups");
//		task1.setTaskStatus("Not started yet");
//		
//		List<Task> taskList=new ArrayList<>();
//		taskList.add(task1);
//		taskList.add(task2);
//		
//		
//		assertEquals(taskList, empImpl.getSantaTask(t));
//		
//		}
//	
	
	
	@Test
	public void getChildSantaDetailsExceptionTest() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		ee.expect(Exception.class);  
		ee.expectMessage("Not enough players! Sorry");
		empImpl.getChildSantaDetails("C");
		
		
}
	
//	@Test
//	public void getChildSantaDetailsGroupTest() throws Exception {
//		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
//		ChildSanta cs1=new ChildSanta();
//		ChildSanta cs2=new ChildSanta();
//		cs1.setSantaId("561657");
//		cs1.setChildId("561658");
//		cs2.setSantaId("561658");
//		cs2.setChildId("561657");
//		
//		List<ChildSanta> childSantaList=new ArrayList<>();
//		childSantaList.add(cs2);
//		childSantaList.add(cs1);
//		
//		assertEquals(childSantaList,empImpl.getChildSantaDetails("A"));
		
		
//}
	

	
//	@Test
//	public void childTaskTest() throws Exception {
//		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
//		Employee emp=new Employee();
//		Task t=new Task();
//		t.setEmpId("561657");
//		Task task1=new Task();
//		task1.setTaskId(1);
//		task1.setTaskDescription("Do pushups");
//		task1.setTaskStatus("Not started yet");
//		
//		Task task2=new Task();
//		task1.setTaskId(2);
//		task1.setTaskDescription("Do pullups");
//		task1.setTaskStatus("Not started yet");
//		
//		List<Task> taskList=new ArrayList<>();
//		taskList.add(task1);
//		taskList.add(task2);
//		
//		
//		assertEquals(taskList, empImpl.getChildTask(t));
//		
//		}
//	
	
	
	@Test
	public void onInitFlags() throws Exception {
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		Map<String, String> flagGroups=new HashMap<>();
		flagGroups.put("A", "false");
		flagGroups.put("B", "true");
		flagGroups.put("C", "true");
		flagGroups.put("assignFlag", "false");
		
		assertEquals(flagGroups, empImpl.onInit());
		
		}
	
	
	@Test
	public void revealSantaTest() throws Exception {
		Employee child=new Employee();
		child.setEmpId("561657");
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		
		assertEquals("Not Completed",empImpl.revealSanta(child) );
		
		
		
	}
	
	
	@Test
	public void getChildTest() throws Exception {
		Employee santa=new Employee();
		santa.setEmpId("561658");
		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
		List<String> childId=new ArrayList<>();
		childId.add("561657");
		assertEquals(childId,empImpl.getChildId(santa));
		
		
		
	}
	
	
//	@Test
//	public void getDetailsTest() throws Exception {
//		Employee emp=new Employee();
//		emp.setEmpId("561657");
//		EmpServiceImpl empImpl=(EmpServiceImpl)ContextFactory.getContext().getBean("EmpService");
//		
//		
//		Employee e=new Employee();
//		
//		LocalDate ld=LocalDate.of(1997,11,22);
//		e.setDateOfBirth(ld);
//		e.setEmpId("561657");
//		e.setGroupId("A");
//		e.setName("Raghav S");
//		e.setPhoneNumber("8807961558");
//		
//		assertEquals(e,empImpl.getDetails(emp));
//			
//	}
	}
